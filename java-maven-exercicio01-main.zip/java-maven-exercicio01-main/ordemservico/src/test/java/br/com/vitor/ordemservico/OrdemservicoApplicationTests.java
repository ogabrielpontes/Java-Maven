package br.com.vitor.ordemservico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdemservicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
